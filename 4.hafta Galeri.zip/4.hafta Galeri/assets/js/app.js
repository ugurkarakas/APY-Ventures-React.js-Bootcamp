for(i = 0; i < 12; i++) {
    var imgList = document.createElement("img");
    imgList.src = "https://source.unsplash.com/random/250x150?" + i;
    document.getElementById("content").appendChild(imgList);
  }